from django.shortcuts import render, redirect
from .models import Patients ######
# Create your views here.
def list_of_patients(request):
    patients = Patients.objects.all() ######
    return render(request, 'list.html', {'patients' : patients}) ######

def create_patients(request):
    if request.method == 'GET':
        return render(request, 'create.html')
    elif request.method == 'POST':
        name = request.POST['name'] 
        disease = request.POST['disease'] 
        age = request.POST['age'] 
        patients = Patients(name = name, disease = disease, age = age)
        patients.save()
        return redirect('list_of_patients')         

def edit_patients(request, id):
    if request.method == 'GET':
        patients = Patients.objects.get(id = id)
        return render(request, 'edit.html', {'patients' :patients})
    elif request.method == 'POST':
        patients = Patients.objects.get(id = id)
        patients.name = request.POST['name'] 
        patients.disease = request.POST['disease'] 
        patients.age = request.POST['age'] 
        patients.save()
        return redirect('list_of_patients')    

        
def delete_patients(request, id):
    patients = Patients.objects.get(id = id)
    patients.delete()
    return redirect('list_of_patients')